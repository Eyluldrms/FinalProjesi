﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kıyafet_mağazası
{
    public partial class personel : UserControl
    {
        public personel()
        {
            InitializeComponent();
        }
        DataTable tablo = new DataTable();

        private void personel_Load(object sender, EventArgs e)
        {
            tablo.Columns.Add("Adı", typeof(string));
            tablo.Columns.Add("Soyadı", typeof(string));
            tablo.Columns.Add("Görevi", typeof(string));
            dataGridView1.DataSource = tablo;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            tablo.Rows.Add(txtad.Text, txtsoyad.Text, txtgorev.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if(dataGridView1.Rows.Count!= 0) {dataGridView1.Rows.Remove(dataGridView1.CurrentRow); }
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            button2.BackColor = SystemColors.ControlDark;
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.DarkOliveGreen;
        }
    }
}
