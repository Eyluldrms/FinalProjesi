﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kıyafet_mağazası
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            siparis1.Hide();
            personel1.Hide();
            ürünler1.Hide();
            anasayfa1.Show();
            anasayfa1.BringToFront();
        }

        private void anasayfa_Load(object sender, EventArgs e)
        {

        }

        private void Ürünler_Load(object sender, EventArgs e)
        { 
        
        }

        private void siparis_Load(object sender, EventArgs e)
        {

        }

        private void personel_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            siparis1.Hide();
            personel1.Hide();
            ürünler1.Show();
            anasayfa1.Hide();
            ürünler1.BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            siparis1.Hide();
            personel1.Hide();
            ürünler1.Hide();
            anasayfa1.Show();
            anasayfa1.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            siparis1.Show();
            personel1.Hide();
            ürünler1.Hide();
            anasayfa1.Hide();
            siparis1.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            siparis1.Hide();
            personel1.Show();
            ürünler1.Hide();
            anasayfa1.Hide();
            personel1.BringToFront();
        }
    }
}
