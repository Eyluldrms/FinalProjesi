﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace kıyafet_mağazası
{
    public partial class siparis : UserControl
    {
        public siparis()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Adresiniz Başarıyla Kaydedildi");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Siparişiniz Alınmıştır, Bizi Tercih Ettiğiniz İçin Teşekkür Ederiz");
        }
    }
}
